import { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar, Doughnut, Pie } from 'react-chartjs-2';
import * as XLSX from 'xlsx';

ChartJS.register(CategoryScale, LinearScale, BarElement, ArcElement, Title, Tooltip, Legend);

// ─── Types ───────────────────────────────────────────────────────────────────

interface Config {
  accessToken: string;
  adAccountId: string;
  apiVersion: string;
}

interface CampaignData {
  id: string;
  name: string;
  status: string;
  spend: number;
  revenue: number;
  roas: number;
  purchases: number;
  cpm: number;
  ctr: number;
  cpc: number;
  impressions: number;
  clicks: number;
}

interface CreativeData {
  id: string;
  name: string;
  campaign: string;
  adset: string;
  impressions: number;
  clicks: number;
  ctr: number;
  spend: number;
  purchases: number;
  revenue: number;
  roas: number;
  cpm: number;
  cpc: number;
  performance: string;
}

interface AggregatedData {
  name: string;
  spend: number;
  impressions: number;
  clicks: number;
  purchases: number;
  revenue: number;
  roas: number;
  ctr: number;
  cpm?: number;
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function extractActionValue(actions: any[] | undefined, type: string): number {
  if (!actions) return 0;
  const action = actions.find((a: any) => a.action_type === type);
  return action ? parseFloat(action.value) : 0;
}

function formatCurrency(val: number): string {
  return `EGP ${val.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function formatNumber(val: number): string {
  return val.toLocaleString('en-US');
}

function formatDate(date: Date): string {
  return date.toISOString().split('T')[0];
}

// ─── API ─────────────────────────────────────────────────────────────────────

/**
 * KEY FIX: The original code used API v18.0 which is deprecated in 2026.
 * This caused "Error: (#100) Tried accessing nonexisting field (insights)"
 * because the entire API version was sunset and endpoints no longer exist.
 *
 * Fix 1: Updated to v21.0
 * Fix 2: Added retry logic - if `action_values` field doesn't exist on the
 *         account (common for non-value-optimized campaigns), we retry without it.
 * Fix 3: Campaigns are fetched separately from insights for status info.
 * Fix 4: Better error messages to help debug issues.
 */

async function fetchMetaAPI(
  baseUrl: string,
  endpoint: string,
  params: Record<string, any>,
  accessToken: string
): Promise<any> {
  const url = `${baseUrl}/${endpoint}`;
  try {
    const response = await axios.get(url, {
      params: { ...params, access_token: accessToken },
    });
    return response.data;
  } catch (error: any) {
    const apiError = error.response?.data?.error;
    if (apiError) {
      // If error is about nonexisting field and we have action_values in fields,
      // retry without action_values
      if (
        apiError.code === 100 &&
        apiError.message &&
        apiError.message.includes('nonexisting field') &&
        params.fields &&
        params.fields.includes('action_values')
      ) {
        console.warn('Retrying without action_values field...');
        const newFields = params.fields
          .replace(',action_values', '')
          .replace('action_values,', '')
          .replace('action_values', '');
        try {
          const retryResponse = await axios.get(url, {
            params: { ...params, fields: newFields, access_token: accessToken },
          });
          return retryResponse.data;
        } catch (retryError: any) {
          const retryApiError = retryError.response?.data?.error;
          throw new Error(retryApiError?.message || retryError.message);
        }
      }
      throw new Error(apiError.message || 'Meta API Error');
    }
    throw error;
  }
}

/** Fetch all pages of results */
async function fetchAllPages(
  baseUrl: string,
  endpoint: string,
  params: Record<string, any>,
  accessToken: string
): Promise<any[]> {
  let allData: any[] = [];
  const firstPage = await fetchMetaAPI(baseUrl, endpoint, params, accessToken);
  if (firstPage.data) {
    allData = allData.concat(firstPage.data);
  }
  // Follow pagination
  let nextUrl = firstPage.paging?.next;
  let pageCount = 0;
  while (nextUrl && pageCount < 10) {
    try {
      const resp = await axios.get(nextUrl);
      if (resp.data?.data) {
        allData = allData.concat(resp.data.data);
      }
      nextUrl = resp.data?.paging?.next;
      pageCount++;
    } catch {
      break;
    }
  }
  return allData;
}

// ─── Main App ────────────────────────────────────────────────────────────────

export default function App() {
  // Auth state
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [config, setConfig] = useState<Config>({
    accessToken: '',
    adAccountId: '',
    apiVersion: 'v21.0',
  });
  const [loginToken, setLoginToken] = useState('');
  const [loginAccount, setLoginAccount] = useState('');
  const [loginAlert, setLoginAlert] = useState<{ type: string; msg: string } | null>(null);

  // Dashboard state
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [activeTab, setActiveTab] = useState('campaigns');

  // Date state
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [datePreset, setDatePreset] = useState('last30days');
  const [roasThreshold, setRoasThreshold] = useState(5);

  // Data state
  const [campaignsData, setCampaignsData] = useState<CampaignData[]>([]);
  const [creativesData, setCreativesData] = useState<CreativeData[]>([]);
  const [placementsData, setPlacementsData] = useState<AggregatedData[]>([]);
  const [demographicsData, setDemographicsData] = useState<AggregatedData[]>([]);
  const [geographicData, setGeographicData] = useState<AggregatedData[]>([]);
  const [hasActionValues, setHasActionValues] = useState(true);
  // hasActionValues is tracked to show warnings in the UI
  void hasActionValues;

  // Filter state
  const [campaignStatusFilter, setCampaignStatusFilter] = useState('all');
  const [campaignRoasFilter, setCampaignRoasFilter] = useState('all');
  const [campaignSort, setCampaignSort] = useState('roas');
  const [creativePerformanceFilter, setCreativePerformanceFilter] = useState('all');
  const [creativeMinSpend, setCreativeMinSpend] = useState(0);

  const baseUrl = `https://graph.facebook.com/${config.apiVersion}`;

  // ─── Initialize ──────────────────────────────────────────────────────────

  useEffect(() => {
    const token = localStorage.getItem('metaToken');
    const account = localStorage.getItem('metaAccount');
    const version = localStorage.getItem('metaApiVersion') || 'v21.0';
    if (token && account) {
      setLoginToken(token);
      setLoginAccount(account);
      setConfig({ accessToken: token, adAccountId: account, apiVersion: version });
      setIsLoggedIn(true);
      initializeDates();
    }
  }, []);

  function initializeDates() {
    const today = new Date();
    const last30 = new Date(today);
    last30.setDate(last30.getDate() - 30);
    setStartDate(formatDate(last30));
    setEndDate(formatDate(today));
  }

  // ─── Login / Logout ─────────────────────────────────────────────────────

  function handleLogin() {
    const token = loginToken.trim();
    let accountId = loginAccount.trim();

    if (!token || !accountId) {
      setLoginAlert({ type: 'error', msg: 'Please enter both access token and ad account ID.' });
      return;
    }

    // Auto-add act_ prefix if missing
    if (!accountId.startsWith('act_')) {
      accountId = `act_${accountId}`;
      setLoginAccount(accountId);
    }

    const version = config.apiVersion;
    setConfig({ accessToken: token, adAccountId: accountId, apiVersion: version });
    localStorage.setItem('metaToken', token);
    localStorage.setItem('metaAccount', accountId);
    localStorage.setItem('metaApiVersion', version);

    setLoginAlert({ type: 'success', msg: 'Connected successfully!' });
    setTimeout(() => {
      setIsLoggedIn(true);
      setLoginAlert(null);
      initializeDates();
    }, 800);
  }

  function handleLogout() {
    if (confirm('Are you sure you want to logout?')) {
      localStorage.clear();
      setIsLoggedIn(false);
      setConfig({ accessToken: '', adAccountId: '', apiVersion: 'v21.0' });
      setCampaignsData([]);
      setCreativesData([]);
      setPlacementsData([]);
      setDemographicsData([]);
      setGeographicData([]);
    }
  }

  // ─── Date Presets ────────────────────────────────────────────────────────

  function handleDatePreset(preset: string) {
    setDatePreset(preset);
    const today = new Date();
    let start: Date | null = null;
    let end: Date | null = null;

    switch (preset) {
      case 'today':
        start = end = new Date(today);
        break;
      case 'yesterday': {
        const y = new Date(today);
        y.setDate(y.getDate() - 1);
        start = end = y;
        break;
      }
      case 'last7days':
        end = new Date(today);
        start = new Date(today);
        start.setDate(start.getDate() - 7);
        break;
      case 'last30days':
        end = new Date(today);
        start = new Date(today);
        start.setDate(start.getDate() - 30);
        break;
      case 'thismonth':
        end = new Date(today);
        start = new Date(today.getFullYear(), today.getMonth(), 1);
        break;
      case 'lastmonth':
        end = new Date(today.getFullYear(), today.getMonth(), 0);
        start = new Date(end.getFullYear(), end.getMonth(), 1);
        break;
      case 'ytd':
        end = new Date(today);
        start = new Date(today.getFullYear(), 0, 1);
        break;
      default:
        return;
    }

    if (start && end) {
      setStartDate(formatDate(start));
      setEndDate(formatDate(end));
    }
  }

  // ─── Load Data ───────────────────────────────────────────────────────────

  const loadData = useCallback(async () => {
    if (!startDate || !endDate) {
      alert('Please select date range');
      return;
    }

    setLoading(true);
    setErrorMsg('');
    let actionValuesAvailable = true;

    try {
      const timeRange = JSON.stringify({ since: startDate, until: endDate });

      // ── Step 1: Fetch campaign statuses ──
      let statusData: any[] = [];
      try {
        statusData = await fetchAllPages(
          baseUrl,
          `${config.adAccountId}/campaigns`,
          { fields: 'id,name,status,effective_status', limit: 500 },
          config.accessToken
        );
      } catch (err: any) {
        console.error('Error fetching campaigns:', err);
        throw new Error(`Failed to fetch campaigns: ${err.message}`);
      }

      // ── Step 2: Fetch campaign-level insights ──
      let campaignInsights: any[] = [];
      const campaignFields = 'campaign_id,campaign_name,spend,impressions,clicks,ctr,cpm,cpc,actions,action_values';
      try {
        campaignInsights = await fetchAllPages(
          baseUrl,
          `${config.adAccountId}/insights`,
          { level: 'campaign', time_range: timeRange, fields: campaignFields, limit: 500 },
          config.accessToken
        );
      } catch (err: any) {
        // If insights failed, try without action_values
        console.warn('Campaign insights failed, retrying without action_values:', err.message);
        actionValuesAvailable = false;
        try {
          const fallbackFields = 'campaign_id,campaign_name,spend,impressions,clicks,ctr,cpm,cpc,actions';
          campaignInsights = await fetchAllPages(
            baseUrl,
            `${config.adAccountId}/insights`,
            { level: 'campaign', time_range: timeRange, fields: fallbackFields, limit: 500 },
            config.accessToken
          );
        } catch (err2: any) {
          throw new Error(`Failed to fetch campaign insights: ${err2.message}`);
        }
      }

      // ── Step 3: Fetch ad-level insights (creatives) ──
      let adInsights: any[] = [];
      const adFields = actionValuesAvailable
        ? 'ad_id,ad_name,adset_name,campaign_name,spend,impressions,clicks,ctr,cpm,cpc,actions,action_values'
        : 'ad_id,ad_name,adset_name,campaign_name,spend,impressions,clicks,ctr,cpm,cpc,actions';
      try {
        adInsights = await fetchAllPages(
          baseUrl,
          `${config.adAccountId}/insights`,
          { level: 'ad', time_range: timeRange, fields: adFields, limit: 500 },
          config.accessToken
        );
      } catch (err: any) {
        console.warn('Ad insights failed:', err.message);
        // Try without action_values
        if (actionValuesAvailable) {
          actionValuesAvailable = false;
          try {
            const fallbackAdFields = 'ad_id,ad_name,adset_name,campaign_name,spend,impressions,clicks,ctr,cpm,cpc,actions';
            adInsights = await fetchAllPages(
              baseUrl,
              `${config.adAccountId}/insights`,
              { level: 'ad', time_range: timeRange, fields: fallbackAdFields, limit: 500 },
              config.accessToken
            );
          } catch {
            console.warn('Ad insights completely failed');
          }
        }
      }

      // ── Step 4: Fetch placement breakdown ──
      let placementInsights: any[] = [];
      const placementFields = actionValuesAvailable
        ? 'spend,impressions,clicks,ctr,cpm,actions,action_values'
        : 'spend,impressions,clicks,ctr,cpm,actions';
      try {
        placementInsights = await fetchAllPages(
          baseUrl,
          `${config.adAccountId}/insights`,
          {
            level: 'account',
            breakdowns: 'publisher_platform,platform_position',
            time_range: timeRange,
            fields: placementFields,
            limit: 500,
          },
          config.accessToken
        );
      } catch (err: any) {
        console.warn('Placement insights failed:', err.message);
      }

      // ── Step 5: Fetch demographics breakdown ──
      let demoInsights: any[] = [];
      const demoFields = actionValuesAvailable
        ? 'spend,impressions,clicks,ctr,actions,action_values'
        : 'spend,impressions,clicks,ctr,actions';
      try {
        demoInsights = await fetchAllPages(
          baseUrl,
          `${config.adAccountId}/insights`,
          {
            level: 'account',
            breakdowns: 'age,gender',
            time_range: timeRange,
            fields: demoFields,
            limit: 500,
          },
          config.accessToken
        );
      } catch (err: any) {
        console.warn('Demographics insights failed:', err.message);
      }

      // ── Step 6: Fetch geographic breakdown ──
      let geoInsights: any[] = [];
      const geoFields = actionValuesAvailable
        ? 'spend,impressions,actions,action_values'
        : 'spend,impressions,actions';
      try {
        geoInsights = await fetchAllPages(
          baseUrl,
          `${config.adAccountId}/insights`,
          {
            level: 'account',
            breakdowns: 'country,region',
            time_range: timeRange,
            fields: geoFields,
            limit: 500,
          },
          config.accessToken
        );
      } catch (err: any) {
        console.warn('Geographic insights failed:', err.message);
      }

      setHasActionValues(actionValuesAvailable);

      // ── Process Data ──
      processCampaigns(campaignInsights, statusData, actionValuesAvailable);
      processCreatives(adInsights, actionValuesAvailable);
      processPlacements(placementInsights, actionValuesAvailable);
      processDemographics(demoInsights, actionValuesAvailable);
      processGeographic(geoInsights, actionValuesAvailable);

      if (!actionValuesAvailable) {
        setErrorMsg(
          'Note: Revenue/ROAS data is unavailable for this account. The "action_values" field is not available — this usually means your campaigns are not optimized for purchase value. Spend, clicks, and other metrics are still shown.'
        );
      }
    } catch (error: any) {
      console.error('Load error:', error);
      setErrorMsg(`Error: ${error.message}`);
    } finally {
      setLoading(false);
    }
  }, [startDate, endDate, config, baseUrl, roasThreshold]);

  // ─── Process Functions ───────────────────────────────────────────────────

  function processCampaigns(insights: any[], statuses: any[], hasValues: boolean) {
    const statusMap: Record<string, string> = {};
    statuses.forEach((s: any) => {
      statusMap[s.id] = s.effective_status || s.status || 'UNKNOWN';
    });

    const processed: CampaignData[] = insights.map((c: any) => {
      const spend = parseFloat(c.spend || 0);
      const purchases = extractActionValue(c.actions, 'purchase');
      const revenue = hasValues ? extractActionValue(c.action_values, 'purchase') : 0;
      const roas = spend > 0 ? revenue / spend : 0;
      return {
        id: c.campaign_id,
        name: c.campaign_name || 'Unknown',
        status: statusMap[c.campaign_id] || 'UNKNOWN',
        spend,
        revenue,
        roas,
        purchases,
        cpm: parseFloat(c.cpm || 0),
        ctr: parseFloat(c.ctr || 0),
        cpc: parseFloat(c.cpc || 0),
        impressions: parseInt(c.impressions || 0),
        clicks: parseInt(c.clicks || 0),
      };
    });

    setCampaignsData(processed);
  }

  function processCreatives(ads: any[], hasValues: boolean) {
    const processed: CreativeData[] = ads.map((a: any) => {
      const spend = parseFloat(a.spend || 0);
      const purchases = extractActionValue(a.actions, 'purchase');
      const revenue = hasValues ? extractActionValue(a.action_values, 'purchase') : 0;
      const roas = spend > 0 ? revenue / spend : 0;
      const ctr = parseFloat(a.ctr || 0);

      let performance: string;
      if (roas >= roasThreshold && ctr >= 1.5) performance = 'top_winner';
      else if (roas >= roasThreshold) performance = 'winner';
      else if (roas < 2) performance = 'loser';
      else performance = 'average';

      return {
        id: a.ad_id,
        name: a.ad_name || 'Unknown',
        campaign: a.campaign_name || '',
        adset: a.adset_name || '',
        impressions: parseInt(a.impressions || 0),
        clicks: parseInt(a.clicks || 0),
        ctr,
        spend,
        purchases,
        revenue,
        roas,
        cpm: parseFloat(a.cpm || 0),
        cpc: parseFloat(a.cpc || 0),
        performance,
      };
    });

    setCreativesData(processed);
  }

  function processPlacements(data: any[], hasValues: boolean) {
    const map: Record<string, any> = {};
    data.forEach((i: any) => {
      const key = `${i.publisher_platform || 'Unknown'} - ${i.platform_position || 'Unknown'}`;
      if (!map[key]) map[key] = { name: key, spend: 0, impressions: 0, clicks: 0, purchases: 0, revenue: 0 };
      map[key].spend += parseFloat(i.spend || 0);
      map[key].impressions += parseInt(i.impressions || 0);
      map[key].clicks += parseInt(i.clicks || 0);
      map[key].purchases += extractActionValue(i.actions, 'purchase');
      map[key].revenue += hasValues ? extractActionValue(i.action_values, 'purchase') : 0;
    });
    setPlacementsData(
      Object.values(map).map((p: any) => ({
        ...p,
        roas: p.spend > 0 ? p.revenue / p.spend : 0,
        ctr: p.impressions > 0 ? (p.clicks / p.impressions) * 100 : 0,
        cpm: p.impressions > 0 ? (p.spend / p.impressions) * 1000 : 0,
      }))
    );
  }

  function processDemographics(data: any[], hasValues: boolean) {
    const map: Record<string, any> = {};
    data.forEach((i: any) => {
      const key = `${i.age || 'Unknown'} - ${i.gender || 'Unknown'}`;
      if (!map[key]) map[key] = { name: key, spend: 0, impressions: 0, clicks: 0, purchases: 0, revenue: 0 };
      map[key].spend += parseFloat(i.spend || 0);
      map[key].impressions += parseInt(i.impressions || 0);
      map[key].clicks += parseInt(i.clicks || 0);
      map[key].purchases += extractActionValue(i.actions, 'purchase');
      map[key].revenue += hasValues ? extractActionValue(i.action_values, 'purchase') : 0;
    });
    setDemographicsData(
      Object.values(map).map((d: any) => ({
        ...d,
        roas: d.spend > 0 ? d.revenue / d.spend : 0,
        ctr: d.impressions > 0 ? (d.clicks / d.impressions) * 100 : 0,
      }))
    );
  }

  function processGeographic(data: any[], hasValues: boolean) {
    const map: Record<string, any> = {};
    data.forEach((i: any) => {
      const key = `${i.country || 'Unknown'} - ${i.region || 'Unknown'}`;
      if (!map[key]) map[key] = { name: key, spend: 0, impressions: 0, purchases: 0, revenue: 0, clicks: 0 };
      map[key].spend += parseFloat(i.spend || 0);
      map[key].impressions += parseInt(i.impressions || 0);
      map[key].purchases += extractActionValue(i.actions, 'purchase');
      map[key].revenue += hasValues ? extractActionValue(i.action_values, 'purchase') : 0;
    });
    setGeographicData(
      Object.values(map).map((g: any) => ({
        ...g,
        roas: g.spend > 0 ? g.revenue / g.spend : 0,
        ctr: 0,
      }))
    );
  }

  // ─── Computed Data ───────────────────────────────────────────────────────

  const totalSpend = campaignsData.reduce((s, c) => s + c.spend, 0);
  const totalRevenue = campaignsData.reduce((s, c) => s + c.revenue, 0);
  const overallRoas = totalSpend > 0 ? totalRevenue / totalSpend : 0;
  const totalPurchases = campaignsData.reduce((s, c) => s + c.purchases, 0);
  const avgCpm = campaignsData.length > 0 ? campaignsData.reduce((s, c) => s + c.cpm, 0) / campaignsData.length : 0;
  const roiPercent = totalSpend > 0 ? ((totalRevenue / totalSpend - 1) * 100).toFixed(1) : '0';

  // Filtered campaigns
  const filteredCampaigns = (() => {
    let arr = [...campaignsData];
    if (campaignStatusFilter !== 'all') arr = arr.filter((c) => c.status === campaignStatusFilter);
    if (campaignRoasFilter === 'winners') arr = arr.filter((c) => c.roas >= roasThreshold);
    else if (campaignRoasFilter === 'losers') arr = arr.filter((c) => c.roas < roasThreshold);
    arr.sort((a, b) => (b as any)[campaignSort] - (a as any)[campaignSort]);
    return arr;
  })();

  // Filtered creatives
  const filteredCreatives = (() => {
    let arr = [...creativesData];
    if (creativePerformanceFilter !== 'all') arr = arr.filter((c) => c.performance === creativePerformanceFilter);
    arr = arr.filter((c) => c.spend >= creativeMinSpend);
    arr.sort((a, b) => b.roas - a.roas);
    return arr;
  })();

  // Insights data
  const winners = campaignsData.filter((c) => c.roas >= roasThreshold).sort((a, b) => b.roas - a.roas).slice(0, 5);
  const losers = campaignsData.filter((c) => c.roas < roasThreshold && c.spend > 0).sort((a, b) => a.roas - b.roas).slice(0, 5);
  const topCreatives = creativesData
    .filter((c) => c.performance === 'top_winner' || c.performance === 'winner')
    .sort((a, b) => b.roas - a.roas)
    .slice(0, 5);
  const badCreatives = creativesData
    .filter((c) => c.performance === 'loser')
    .sort((a, b) => a.roas - b.roas)
    .slice(0, 5);

  // ─── Export ──────────────────────────────────────────────────────────────

  function exportToExcel() {
    if (campaignsData.length === 0) {
      alert('No data to export');
      return;
    }

    const wb = XLSX.utils.book_new();

    const campaignSheet = campaignsData.map((c) => ({
      Campaign: c.name,
      Status: c.status,
      Spend: c.spend.toFixed(2),
      Revenue: c.revenue.toFixed(2),
      ROAS: c.roas.toFixed(2),
      Purchases: c.purchases,
      CPM: c.cpm.toFixed(2),
      CTR: c.ctr.toFixed(2),
      Impressions: c.impressions,
      Clicks: c.clicks,
    }));
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(campaignSheet), 'Campaigns');

    if (creativesData.length > 0) {
      const creativeSheet = creativesData.map((c) => ({
        'Ad Name': c.name,
        Campaign: c.campaign,
        Performance: c.performance,
        Spend: c.spend.toFixed(2),
        Revenue: c.revenue.toFixed(2),
        ROAS: c.roas.toFixed(2),
        Purchases: c.purchases,
        CTR: c.ctr.toFixed(2),
      }));
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(creativeSheet), 'Creatives');
    }

    if (placementsData.length > 0) {
      const placementSheet = placementsData.map((p) => ({
        Placement: p.name,
        Spend: p.spend.toFixed(2),
        Revenue: p.revenue.toFixed(2),
        ROAS: p.roas.toFixed(2),
        Purchases: p.purchases,
      }));
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(placementSheet), 'Placements');
    }

    if (demographicsData.length > 0) {
      const demoSheet = demographicsData.map((d) => ({
        Demographic: d.name,
        Spend: d.spend.toFixed(2),
        Revenue: d.revenue.toFixed(2),
        ROAS: d.roas.toFixed(2),
        Purchases: d.purchases,
      }));
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(demoSheet), 'Demographics');
    }

    if (geographicData.length > 0) {
      const geoSheet = geographicData.map((g) => ({
        Location: g.name,
        Spend: g.spend.toFixed(2),
        Revenue: g.revenue.toFixed(2),
        ROAS: g.roas.toFixed(2),
        Purchases: g.purchases,
      }));
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(geoSheet), 'Geographic');
    }

    XLSX.writeFile(wb, `Meta_Ads_${startDate}_to_${endDate}.xlsx`);
  }

  // ─── Chart Configs ───────────────────────────────────────────────────────

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: true,
    plugins: { legend: { display: false } },
  };

  const chartOptionsWithLegend = {
    responsive: true,
    maintainAspectRatio: true,
    plugins: { legend: { position: 'bottom' as const } },
  };

  const horizontalBarOptions = {
    responsive: true,
    maintainAspectRatio: true,
    indexAxis: 'y' as const,
    plugins: { legend: { display: false } },
  };

  // ─── Render ──────────────────────────────────────────────────────────────

  if (!isLoggedIn) {
    return (
      <div className="container">
        <div className="header">
          <div className="header-content">
            <h1><i className="fas fa-chart-line"></i> Meta Ads Analytics Dashboard</h1>
            <p>Real-time Performance Tracking with ROAS Analysis (EGP)</p>
          </div>
        </div>

        <div className="login-section">
          <h2><i className="fas fa-key"></i> Enter Your Credentials</h2>
          <p style={{ color: 'var(--text-light)', marginBottom: 30, textAlign: 'center' }}>
            Enter your Meta Ads access token and account ID
          </p>

          {loginAlert && (
            <div className={`alert alert-${loginAlert.type}`}>
              <i className={`fas fa-${loginAlert.type === 'success' ? 'check-circle' : 'exclamation-triangle'}`}></i>
              {loginAlert.msg}
            </div>
          )}

          <div className="control-group">
            <label><i className="fas fa-lock"></i> Access Token</label>
            <input
              type="password"
              value={loginToken}
              onChange={(e) => setLoginToken(e.target.value)}
              placeholder="Enter your access token"
            />
          </div>

          <div className="control-group">
            <label><i className="fas fa-hashtag"></i> Ad Account ID</label>
            <input
              type="text"
              value={loginAccount}
              onChange={(e) => setLoginAccount(e.target.value)}
              placeholder="act_XXXXXXXXXX"
            />
          </div>

          <div className="control-group">
            <label><i className="fas fa-code-branch"></i> API Version</label>
            <select
              value={config.apiVersion}
              onChange={(e) => setConfig((prev) => ({ ...prev, apiVersion: e.target.value }))}
            >
              <option value="v21.0">v21.0 (Recommended)</option>
              <option value="v20.0">v20.0</option>
              <option value="v19.0">v19.0</option>
              <option value="v22.0">v22.0</option>
            </select>
          </div>

          <button className="btn btn-primary full" onClick={handleLogin} style={{ marginTop: 25 }}>
            <i className="fas fa-sign-in-alt"></i> Access Dashboard
          </button>

          <p style={{ color: 'var(--text-light)', marginTop: 25, fontSize: '0.9em', textAlign: 'center' }}>
            <i className="fas fa-info-circle"></i> Your credentials are stored locally in your browser
          </p>
        </div>
      </div>
    );
  }

  // ─── Dashboard ───────────────────────────────────────────────────────────

  const sortedPlacements = [...placementsData].sort((a, b) => b.roas - a.roas);
  const sortedDemographics = [...demographicsData].sort((a, b) => b.roas - a.roas);
  const sortedGeographic = [...geographicData].sort((a, b) => b.roas - a.roas);

  const performanceLabels: Record<string, string> = {
    top_winner: '🏆 TOP',
    winner: '🟢 WIN',
    average: '🟡 AVG',
    loser: '🔴 LOSE',
  };

  const performanceBadgeClass: Record<string, string> = {
    top_winner: 'badge-success',
    winner: 'badge-info',
    average: 'badge-warning',
    loser: 'badge-danger',
  };

  // Winner/loser spend for budget chart
  const winnerSpend = winners.reduce((s, c) => s + c.spend, 0);
  const avgCampaignSpend = campaignsData.filter((c) => c.roas >= 2 && c.roas < roasThreshold).reduce((s, c) => s + c.spend, 0);
  const loserSpend = losers.reduce((s, c) => s + c.spend, 0);

  // Campaign status counts
  const activeCount = campaignsData.filter((c) => c.status === 'ACTIVE').length;
  const pausedCount = campaignsData.filter((c) => c.status === 'PAUSED').length;
  const archivedCount = campaignsData.filter((c) => !['ACTIVE', 'PAUSED'].includes(c.status)).length;

  // Creative distribution
  const creativeDistribution = {
    top_winner: creativesData.filter((c) => c.performance === 'top_winner').length,
    winner: creativesData.filter((c) => c.performance === 'winner').length,
    average: creativesData.filter((c) => c.performance === 'average').length,
    loser: creativesData.filter((c) => c.performance === 'loser').length,
  };

  const tabs = [
    { id: 'campaigns', label: 'Campaigns', icon: 'fa-bullhorn' },
    { id: 'creatives', label: 'Creatives', icon: 'fa-palette' },
    { id: 'placements', label: 'Placements', icon: 'fa-map-marker-alt' },
    { id: 'demographics', label: 'Demographics', icon: 'fa-users' },
    { id: 'geographic', label: 'Geographic', icon: 'fa-globe' },
    { id: 'insights', label: 'Insights', icon: 'fa-lightbulb' },
  ];

  return (
    <div className="container">
      <div className="header">
        <div className="header-content">
          <h1><i className="fas fa-chart-line"></i> Meta Ads Analytics Dashboard</h1>
          <p>Real-time Performance Tracking with ROAS Analysis (EGP) — API {config.apiVersion}</p>
        </div>
      </div>

      {/* Controls */}
      <div className="controls">
        <div className="controls-grid">
          <div className="control-group">
            <label><i className="fas fa-calendar-alt"></i> Start Date</label>
            <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
          </div>
          <div className="control-group">
            <label><i className="fas fa-calendar-check"></i> End Date</label>
            <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
          </div>
          <div className="control-group">
            <label><i className="fas fa-bolt"></i> Quick Select</label>
            <select value={datePreset} onChange={(e) => handleDatePreset(e.target.value)}>
              <option value="custom">Custom</option>
              <option value="today">Today</option>
              <option value="yesterday">Yesterday</option>
              <option value="last7days">Last 7 Days</option>
              <option value="last30days">Last 30 Days</option>
              <option value="thismonth">This Month</option>
              <option value="lastmonth">Last Month</option>
              <option value="ytd">Year to Date</option>
            </select>
          </div>
          <div className="control-group">
            <label><i className="fas fa-bullseye"></i> ROAS Threshold</label>
            <input
              type="number"
              value={roasThreshold}
              onChange={(e) => setRoasThreshold(parseFloat(e.target.value) || 5)}
              step="0.5"
              min="1"
            />
          </div>
        </div>
        <div className="btn-group">
          <button className="btn btn-primary" onClick={loadData} disabled={loading}>
            <i className={`fas ${loading ? 'fa-spinner fa-spin' : 'fa-sync-alt'}`}></i>
            {loading ? 'Loading...' : 'Load Data'}
          </button>
          <button className="btn btn-success" onClick={exportToExcel}>
            <i className="fas fa-file-excel"></i> Export Excel
          </button>
          <button className="btn btn-danger" onClick={handleLogout}>
            <i className="fas fa-sign-out-alt"></i> Logout
          </button>
        </div>
      </div>

      {/* Loading */}
      {loading && (
        <div className="loading">
          <div className="spinner"></div>
          <p>Loading data from Meta Ads API ({config.apiVersion})...</p>
        </div>
      )}

      {/* Error/Warning */}
      {errorMsg && (
        <div className={`alert ${errorMsg.startsWith('Note:') ? 'alert-success' : 'alert-error'}`} style={{ marginBottom: 20 }}>
          <i className={`fas ${errorMsg.startsWith('Note:') ? 'fa-info-circle' : 'fa-exclamation-triangle'}`}></i>
          <div>{errorMsg}</div>
        </div>
      )}

      {/* KPI Cards */}
      <div className="kpi-grid">
        <div className="kpi-card">
          <h3><i className="fas fa-wallet"></i> Total Spend</h3>
          <div className="value">{formatCurrency(totalSpend)}</div>
        </div>
        <div className="kpi-card">
          <h3><i className="fas fa-money-bill-wave"></i> Total Revenue</h3>
          <div className="value">{formatCurrency(totalRevenue)}</div>
          <div className={`delta ${parseFloat(roiPercent) >= 0 ? 'positive' : 'negative'}`}>
            <i className={`fas fa-arrow-${parseFloat(roiPercent) >= 0 ? 'up' : 'down'}`}></i> {roiPercent}% ROI
          </div>
        </div>
        <div className="kpi-card">
          <h3><i className="fas fa-chart-line"></i> Overall ROAS</h3>
          <div className="value">{overallRoas.toFixed(2)}x</div>
          <div className={`delta ${overallRoas >= roasThreshold ? 'positive' : 'negative'}`}>
            <i className={`fas fa-${overallRoas >= roasThreshold ? 'check-circle' : 'exclamation-triangle'}`}></i>
            {overallRoas >= roasThreshold ? ' Above Target' : ' Below Target'}
          </div>
        </div>
        <div className="kpi-card">
          <h3><i className="fas fa-shopping-cart"></i> Total Purchases</h3>
          <div className="value">{formatNumber(totalPurchases)}</div>
        </div>
        <div className="kpi-card">
          <h3><i className="fas fa-eye"></i> Average CPM</h3>
          <div className="value">{formatCurrency(avgCpm)}</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="tabs">
        <div className="tab-buttons">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              className={`tab-button ${activeTab === tab.id ? 'active' : ''}`}
              onClick={() => setActiveTab(tab.id)}
            >
              <i className={`fas ${tab.icon}`}></i> {tab.label}
            </button>
          ))}
        </div>

        {/* ── Campaigns Tab ── */}
        {activeTab === 'campaigns' && (
          <div className="tab-content">
            <h2>Campaign Performance</h2>

            <div className="filter-section">
              <div className="filter-grid">
                <div className="control-group">
                  <label>Filter by Status</label>
                  <select value={campaignStatusFilter} onChange={(e) => setCampaignStatusFilter(e.target.value)}>
                    <option value="all">All Campaigns</option>
                    <option value="ACTIVE">Active Only</option>
                    <option value="PAUSED">Paused Only</option>
                  </select>
                </div>
                <div className="control-group">
                  <label>Filter by ROAS</label>
                  <select value={campaignRoasFilter} onChange={(e) => setCampaignRoasFilter(e.target.value)}>
                    <option value="all">All</option>
                    <option value="winners">Winners (≥{roasThreshold})</option>
                    <option value="losers">Losers (&lt;{roasThreshold})</option>
                  </select>
                </div>
                <div className="control-group">
                  <label>Sort By</label>
                  <select value={campaignSort} onChange={(e) => setCampaignSort(e.target.value)}>
                    <option value="roas">ROAS</option>
                    <option value="spend">Spend</option>
                    <option value="revenue">Revenue</option>
                    <option value="purchases">Purchases</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="table-container">
              <table>
                <thead>
                  <tr>
                    <th>Campaign</th>
                    <th>Status</th>
                    <th>Spend</th>
                    <th>Revenue</th>
                    <th>ROAS</th>
                    <th>Purchases</th>
                    <th>CPM</th>
                    <th>CTR</th>
                    <th>Impressions</th>
                    <th>Clicks</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredCampaigns.length === 0 ? (
                    <tr>
                      <td colSpan={10} className="empty-state">
                        <i className="fas fa-database"></i>
                        <p>{campaignsData.length === 0 ? 'Click "Load Data" to fetch campaigns' : 'No campaigns match filters'}</p>
                      </td>
                    </tr>
                  ) : (
                    filteredCampaigns.map((c) => (
                      <tr key={c.id}>
                        <td><strong>{c.name}</strong></td>
                        <td>
                          <span className={`badge badge-${c.status === 'ACTIVE' ? 'success' : 'warning'}`}>
                            {c.status}
                          </span>
                        </td>
                        <td>{formatCurrency(c.spend)}</td>
                        <td>{formatCurrency(c.revenue)}</td>
                        <td>
                          <span className={c.roas >= roasThreshold ? 'roas-winner' : 'roas-loser'}>
                            {c.roas.toFixed(2)}x
                          </span>
                        </td>
                        <td>{formatNumber(c.purchases)}</td>
                        <td>{formatCurrency(c.cpm)}</td>
                        <td>{c.ctr.toFixed(2)}%</td>
                        <td>{formatNumber(c.impressions)}</td>
                        <td>{formatNumber(c.clicks)}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {filteredCampaigns.length > 0 && (
              <div className="chart-grid">
                <div className="chart-container">
                  <h3>ROAS by Campaign</h3>
                  <Bar
                    data={{
                      labels: filteredCampaigns.slice(0, 10).map((c) => c.name.substring(0, 30)),
                      datasets: [
                        {
                          label: 'ROAS',
                          data: filteredCampaigns.slice(0, 10).map((c) => c.roas),
                          backgroundColor: filteredCampaigns.slice(0, 10).map((c) =>
                            c.roas >= roasThreshold ? '#10b981' : '#ef4444'
                          ),
                          borderRadius: 8,
                        },
                      ],
                    }}
                    options={chartOptions}
                  />
                </div>
                <div className="chart-container">
                  <h3>Spend vs Revenue</h3>
                  <Bar
                    data={{
                      labels: filteredCampaigns.slice(0, 10).map((c) => c.name.substring(0, 30)),
                      datasets: [
                        { label: 'Spend', data: filteredCampaigns.slice(0, 10).map((c) => c.spend), backgroundColor: '#3b82f6', borderRadius: 8 },
                        { label: 'Revenue', data: filteredCampaigns.slice(0, 10).map((c) => c.revenue), backgroundColor: '#10b981', borderRadius: 8 },
                      ],
                    }}
                    options={{ responsive: true, maintainAspectRatio: true }}
                  />
                </div>
              </div>
            )}
          </div>
        )}

        {/* ── Creatives Tab ── */}
        {activeTab === 'creatives' && (
          <div className="tab-content">
            <h2>Creative Performance</h2>

            <div className="filter-section">
              <div className="filter-grid">
                <div className="control-group">
                  <label>Performance</label>
                  <select value={creativePerformanceFilter} onChange={(e) => setCreativePerformanceFilter(e.target.value)}>
                    <option value="all">All</option>
                    <option value="top_winner">🏆 Top Winners</option>
                    <option value="winner">🟢 Winners</option>
                    <option value="average">🟡 Average</option>
                    <option value="loser">🔴 Losers</option>
                  </select>
                </div>
                <div className="control-group">
                  <label>Min Spend</label>
                  <input
                    type="number"
                    value={creativeMinSpend}
                    onChange={(e) => setCreativeMinSpend(parseFloat(e.target.value) || 0)}
                    min="0"
                  />
                </div>
              </div>
            </div>

            <div className="table-container">
              <table>
                <thead>
                  <tr>
                    <th>Ad Name</th>
                    <th>Campaign</th>
                    <th>Performance</th>
                    <th>Spend</th>
                    <th>Revenue</th>
                    <th>ROAS</th>
                    <th>CTR</th>
                    <th>Purchases</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredCreatives.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="empty-state">
                        <i className="fas fa-image"></i>
                        <p>No creatives data</p>
                      </td>
                    </tr>
                  ) : (
                    filteredCreatives.map((c) => (
                      <tr key={c.id + c.campaign}>
                        <td><strong>{c.name}</strong></td>
                        <td>{c.campaign}</td>
                        <td><span className={`badge ${performanceBadgeClass[c.performance]}`}>{performanceLabels[c.performance]}</span></td>
                        <td>{formatCurrency(c.spend)}</td>
                        <td>{formatCurrency(c.revenue)}</td>
                        <td><span className={c.roas >= roasThreshold ? 'roas-winner' : 'roas-loser'}>{c.roas.toFixed(2)}x</span></td>
                        <td>{c.ctr.toFixed(2)}%</td>
                        <td>{formatNumber(c.purchases)}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {filteredCreatives.length > 0 && (
              <div className="chart-grid">
                <div className="chart-container">
                  <h3>Performance Distribution</h3>
                  <Doughnut
                    data={{
                      labels: ['🏆 Top', '🟢 Winners', '🟡 Avg', '🔴 Losers'],
                      datasets: [
                        {
                          data: [creativeDistribution.top_winner, creativeDistribution.winner, creativeDistribution.average, creativeDistribution.loser],
                          backgroundColor: ['#10b981', '#34d399', '#fbbf24', '#ef4444'],
                          borderWidth: 0,
                        },
                      ],
                    }}
                    options={chartOptionsWithLegend}
                  />
                </div>
                <div className="chart-container">
                  <h3>Top Creatives by ROAS</h3>
                  <Bar
                    data={{
                      labels: filteredCreatives.slice(0, 10).map((c) => c.name.substring(0, 30)),
                      datasets: [{ label: 'ROAS', data: filteredCreatives.slice(0, 10).map((c) => c.roas), backgroundColor: '#10b981', borderRadius: 8 }],
                    }}
                    options={horizontalBarOptions}
                  />
                </div>
              </div>
            )}

            <div className="insight-grid">
              <div className="insight-card winner">
                <h3>🏆 Scale These</h3>
                {topCreatives.length === 0 ? (
                  <p>Load data to see insights</p>
                ) : (
                  topCreatives.map((c) => (
                    <div className="insight-item" key={c.id}>
                      <h4>{c.name}</h4>
                      <p>ROAS: {c.roas.toFixed(2)}x | CTR: {c.ctr.toFixed(2)}%</p>
                      <p>Action: Create variations</p>
                    </div>
                  ))
                )}
              </div>
              <div className="insight-card loser">
                <h3>🔴 Pause These</h3>
                {badCreatives.length === 0 ? (
                  <p>Load data to see insights</p>
                ) : (
                  badCreatives.map((c) => (
                    <div className="insight-item" key={c.id}>
                      <h4>{c.name}</h4>
                      <p>ROAS: {c.roas.toFixed(2)}x | Wasted: {formatCurrency(c.spend)}</p>
                      <p>Action: Pause now</p>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {/* ── Placements Tab ── */}
        {activeTab === 'placements' && (
          <div className="tab-content">
            <h2>Placement Performance</h2>
            <div className="table-container">
              <table>
                <thead>
                  <tr>
                    <th>Placement</th>
                    <th>Spend</th>
                    <th>Revenue</th>
                    <th>ROAS</th>
                    <th>CTR</th>
                    <th>Purchases</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedPlacements.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="empty-state">
                        <i className="fas fa-th"></i>
                        <p>No placement data</p>
                      </td>
                    </tr>
                  ) : (
                    sortedPlacements.map((p, i) => (
                      <tr key={i}>
                        <td><strong>{p.name}</strong></td>
                        <td>{formatCurrency(p.spend)}</td>
                        <td>{formatCurrency(p.revenue)}</td>
                        <td>{p.roas.toFixed(2)}x</td>
                        <td>{p.ctr.toFixed(2)}%</td>
                        <td>{formatNumber(p.purchases)}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
            {sortedPlacements.length > 0 && (
              <div className="chart-grid">
                <div className="chart-container">
                  <h3>ROAS by Placement</h3>
                  <Bar
                    data={{
                      labels: sortedPlacements.slice(0, 10).map((p) => p.name),
                      datasets: [{ label: 'ROAS', data: sortedPlacements.slice(0, 10).map((p) => p.roas), backgroundColor: '#3b82f6', borderRadius: 8 }],
                    }}
                    options={horizontalBarOptions}
                  />
                </div>
                <div className="chart-container">
                  <h3>Spend Distribution</h3>
                  <Doughnut
                    data={{
                      labels: sortedPlacements.slice(0, 10).map((p) => p.name),
                      datasets: [
                        {
                          data: sortedPlacements.slice(0, 10).map((p) => p.spend),
                          backgroundColor: ['#ef4444', '#f59e0b', '#10b981', '#3b82f6', '#6366f1', '#8b5cf6', '#ec4899', '#14b8a6', '#f97316', '#84cc16'],
                          borderWidth: 0,
                        },
                      ],
                    }}
                    options={chartOptionsWithLegend}
                  />
                </div>
              </div>
            )}
          </div>
        )}

        {/* ── Demographics Tab ── */}
        {activeTab === 'demographics' && (
          <div className="tab-content">
            <h2>Demographics</h2>
            <div className="table-container">
              <table>
                <thead>
                  <tr>
                    <th>Age - Gender</th>
                    <th>Spend</th>
                    <th>Revenue</th>
                    <th>ROAS</th>
                    <th>Purchases</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedDemographics.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="empty-state">
                        <i className="fas fa-users"></i>
                        <p>No demographic data</p>
                      </td>
                    </tr>
                  ) : (
                    sortedDemographics.map((d, i) => (
                      <tr key={i}>
                        <td><strong>{d.name}</strong></td>
                        <td>{formatCurrency(d.spend)}</td>
                        <td>{formatCurrency(d.revenue)}</td>
                        <td>{d.roas.toFixed(2)}x</td>
                        <td>{formatNumber(d.purchases)}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
            {sortedDemographics.length > 0 && (
              <div className="chart-grid">
                <div className="chart-container">
                  <h3>ROAS by Demographic</h3>
                  <Bar
                    data={{
                      labels: sortedDemographics.slice(0, 15).map((d) => d.name),
                      datasets: [{ label: 'ROAS', data: sortedDemographics.slice(0, 15).map((d) => d.roas), backgroundColor: '#10b981', borderRadius: 8 }],
                    }}
                    options={horizontalBarOptions}
                  />
                </div>
                <div className="chart-container">
                  <h3>Purchases</h3>
                  <Bar
                    data={{
                      labels: sortedDemographics.slice(0, 15).map((d) => d.name),
                      datasets: [{ label: 'Purchases', data: sortedDemographics.slice(0, 15).map((d) => d.purchases), backgroundColor: '#3b82f6', borderRadius: 8 }],
                    }}
                    options={horizontalBarOptions}
                  />
                </div>
              </div>
            )}
          </div>
        )}

        {/* ── Geographic Tab ── */}
        {activeTab === 'geographic' && (
          <div className="tab-content">
            <h2>Geographic Performance</h2>
            <div className="table-container">
              <table>
                <thead>
                  <tr>
                    <th>Location</th>
                    <th>Spend</th>
                    <th>Revenue</th>
                    <th>ROAS</th>
                    <th>Purchases</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedGeographic.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="empty-state">
                        <i className="fas fa-globe"></i>
                        <p>No geographic data</p>
                      </td>
                    </tr>
                  ) : (
                    sortedGeographic.map((g, i) => (
                      <tr key={i}>
                        <td><strong>{g.name}</strong></td>
                        <td>{formatCurrency(g.spend)}</td>
                        <td>{formatCurrency(g.revenue)}</td>
                        <td>{g.roas.toFixed(2)}x</td>
                        <td>{formatNumber(g.purchases)}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
            {sortedGeographic.length > 0 && (
              <div className="chart-grid">
                <div className="chart-container">
                  <h3>ROAS by Location</h3>
                  <Bar
                    data={{
                      labels: sortedGeographic.slice(0, 15).map((g) => g.name),
                      datasets: [{ label: 'ROAS', data: sortedGeographic.slice(0, 15).map((g) => g.roas), backgroundColor: '#6366f1', borderRadius: 8 }],
                    }}
                    options={horizontalBarOptions}
                  />
                </div>
                <div className="chart-container">
                  <h3>Revenue by Location</h3>
                  <Bar
                    data={{
                      labels: sortedGeographic.slice(0, 15).map((g) => g.name),
                      datasets: [{ label: 'Revenue', data: sortedGeographic.slice(0, 15).map((g) => g.revenue), backgroundColor: '#10b981', borderRadius: 8 }],
                    }}
                    options={horizontalBarOptions}
                  />
                </div>
              </div>
            )}
          </div>
        )}

        {/* ── Insights Tab ── */}
        {activeTab === 'insights' && (
          <div className="tab-content">
            <h2>Insights &amp; Actions</h2>

            <div className="insight-grid">
              <div className="insight-card winner">
                <h3>✅ Scale These Campaigns</h3>
                {winners.length === 0 ? (
                  <p>Load data to see insights</p>
                ) : (
                  winners.map((c) => (
                    <div className="insight-item" key={c.id}>
                      <h4>{c.name}</h4>
                      <p>ROAS: {c.roas.toFixed(2)}x | Spend: {formatCurrency(c.spend)}</p>
                      <p>Action: Increase budget 20-30%</p>
                    </div>
                  ))
                )}
              </div>
              <div className="insight-card loser">
                <h3>❌ Pause These Campaigns</h3>
                {losers.length === 0 ? (
                  <p>Load data to see insights</p>
                ) : (
                  losers.map((c) => (
                    <div className="insight-item" key={c.id}>
                      <h4>{c.name}</h4>
                      <p>ROAS: {c.roas.toFixed(2)}x | Wasted: {formatCurrency(c.spend)}</p>
                      <p>Action: Pause or reduce 50%</p>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Priority Actions */}
            <div style={{ background: 'white', padding: 35, borderRadius: 20, marginTop: 30, boxShadow: '0 5px 20px rgba(0,0,0,0.08)' }}>
              <h3>📋 Priority Actions</h3>
              <div style={{ marginTop: 20 }}>
                {campaignsData.length === 0 ? (
                  <p>Load data to see actions</p>
                ) : (
                  <>
                    {loserSpend > 0 && (
                      <div className="alert alert-error">
                        <i className="fas fa-exclamation-triangle"></i>
                        <div>
                          <strong>HIGH: Pause {losers.length} underperforming campaigns</strong>
                          <p>Potential savings: {formatCurrency(loserSpend)}</p>
                        </div>
                      </div>
                    )}
                    {badCreatives.length > 0 && (
                      <div className="alert alert-error">
                        <i className="fas fa-times-circle"></i>
                        <div>
                          <strong>HIGH: Pause {badCreatives.length} underperforming creatives</strong>
                          <p>Potential savings: {formatCurrency(badCreatives.reduce((s, c) => s + c.spend, 0))}</p>
                        </div>
                      </div>
                    )}
                    {winners.length > 0 && (
                      <div className="alert alert-success">
                        <i className="fas fa-check-circle"></i>
                        <div>
                          <strong>MEDIUM: Scale {winners.length} winning campaigns</strong>
                          <p>Revenue opportunity: {formatCurrency(winners.reduce((s, c) => s + c.revenue, 0))}</p>
                        </div>
                      </div>
                    )}
                    {loserSpend === 0 && badCreatives.length === 0 && winners.length === 0 && (
                      <p style={{ color: 'var(--text-light)' }}>No specific actions available with current data.</p>
                    )}
                  </>
                )}
              </div>
            </div>

            {campaignsData.length > 0 && (
              <div className="chart-grid" style={{ marginTop: 30 }}>
                <div className="chart-container">
                  <h3>Budget Allocation</h3>
                  <Doughnut
                    data={{
                      labels: ['Winners', 'Average', 'Losers'],
                      datasets: [
                        {
                          data: [winnerSpend, avgCampaignSpend, loserSpend],
                          backgroundColor: ['#10b981', '#fbbf24', '#ef4444'],
                          borderWidth: 0,
                        },
                      ],
                    }}
                    options={chartOptionsWithLegend}
                  />
                </div>
                <div className="chart-container">
                  <h3>Campaign Status</h3>
                  <Pie
                    data={{
                      labels: ['Active', 'Paused', 'Other'],
                      datasets: [
                        {
                          data: [activeCount, pausedCount, archivedCount],
                          backgroundColor: ['#10b981', '#fbbf24', '#6b7280'],
                          borderWidth: 0,
                        },
                      ],
                    }}
                    options={chartOptionsWithLegend}
                  />
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
